//import libraries
import {world} from 'mojang-minecraft';

//prefix
const commandPrefix = '+';
const commandList = ["lobby","shop"];
let reply = [];

//run saat ada chat
world.events.beforeChat.subscribe(msg => {
	//main command
	if (msg.message.substr(0, commandPrefix.length) == commandPrefix) {
		//init sequence
		let args_ = msg.message.slice(commandPrefix.length).trim().split(' '); //ambil(grap) command and arguments
		let command = args_.shift().toLowerCase(); //ambil command
		let args = args_.join('_').toLowerCase(); //ambil arguments

		let player = msg.sender.name ?? msg.sender.nameTag; //ambil nama pemain || get player name
		msg.cancel = true; //cancel chat

		//test apa ini command yg butuh argument || test need argumet or not
		

		
		let playerDimension = currentDimension(player);
		let playerDimId = dimToId(playerDimension);
		
		let getHomeTag = runCmd(`tag "${player}" list`,world.getDimension("overworld")).statusMessage;
		let homeReg = new RegExp(`§4§kH_${args}D_(\\d+)X_(-\\d+|\\d+)Y_(-\\d+|\\d+)Z_(-\\d+|\\d+)§r`);
		let homeNamesReg = /(?<=§4§kH_).+?(?=D_(\d+)X_(-\d+|\d+)Y_(-\d+|\d+)Z_(-\d+|\d+)§r)/g;

		let homeFind = getHomeTag.match(homeReg);
		
    
		
		let homeDimensionName = "overworld";
		
		
		
		/*
		//debug
		runCmd(`tellraw "${player}" { "rawtext": [ { "text": "§1home x = ${homeTagX[0]}" } ] }`, world.getDimension("overworld"));
		runCmd(`tellraw "${player}" { "rawtext": [ { "text": "§1home y = ${homeTagY[0]}" } ] }`, world.getDimension("overworld"));
		runCmd(`tellraw "${player}" { "rawtext": [ { "text": "§1home z = ${homeTagZ[0]}" } ] }`, world.getDimension("overworld"));
		runCmd(`tellraw "${player}" { "rawtext": [ { "text": "§1home dimension = ${homeDimension[0]}" } ] }`, world.getDimension("overworld"));
		runCmd(`tellraw "${player}" { "rawtext": [ { "text": "§1home dimension name = ${homeDimensionName}" } ] }`, world.getDimension("overworld"));
		runCmd(`tellraw "${player}" { "rawtext": [ { "text": "§1all home name = ${allHomeName}" } ] }`, world.getDimension("overworld"));
		runCmd(`tellraw "${player}" { "rawtext": [ { "text": "§1home name = ${homeName}" } ] }`, world.getDimension("overworld"));
		runCmd(`tellraw "${player}" { "rawtext": [ { "text": "§1player dimension = ${playerDimension}" } ] }`, world.getDimension("overworld"));
		runCmd(`tellraw "${player}" { "rawtext": [ { "text": "§1player dimension = ${playerDimension}" } ] }`, world.getDimension("overworld"));
		runCmd(`tellraw "${player}" { "rawtext": [ { "text": "§1player dimension id = ${playerDimId}" } ] }`, world.getDimension("overworld"));
    */

		//blok main command
		switch (command) {
			case 'shop':
				runCmd(`tellraw "${player}" { "rawtext": [ { "text": "bạn đã tp đến shop" } ] }`,world.getDimension("overworld"));
				 runCmd(`tp "${player}" 20 -60 0`,world.getDimension("overworld"));
				break;
			case 'lobby':
					runCmd(`tp "${player}" 0 -60 0`,world.getDimension("overworld"));
					 runCmd(`tellraw "${player}" { "rawtext": [ { "text": "bạn đã tp đến lobby" } ] }`, world.getDimension("overworld"));
				break;
		}
	}
})

//get player dimension
function currentDimension(player) {
	let over = true;
	let nether = true;
	try {
		runCmd(`execute "${player}" ~ ~ ~ testforblock ~ -64 ~ bedrock`,world.getDimension("overworld"));
	} catch (e) {
		over = false;
	}
	try {
		runCmd(`execute "${player}" ~ ~ ~ testforblock ~ 127 ~ bedrock`,world.getDimension("nether"));
	} catch (e) {
		nether = false;
	}
	if (over) {
		return "overworld"
	} else if (nether) {
		return "nether"
	} else {
		return "the end"
	}
}
//convert dimension to id
function dimToId(dimension) {
	if (dimension == "overworld") {
		return "0"
	}
	if (dimension == "nether") {
		return "1"
	}
	if (dimension == "the end") {
		return "2"
	}
}
//convert id to dimension
function idToDim(dimension) {
	if (dimension == 0 || dimension == "0") {
		return "overworld"
	}
	if (dimension == 1 || dimension == "1") {
		return "nether"
	}
	if (dimension == 2 || dimension == "2") {
		return "the end"
	}
}
//run command
function runCmd(cmd, dim) {
	return dim.runCommand(cmd);
}
// just for debug
function say(msg) {
	runCmd(`say ${msg}`,world.getDimension("overworld"));
}

function tryCmd(cmd,dim) {
    try {
        return{
            result:runCmd(cmd,dim),
            error:false
        }
    } catch (e) {
        return{
            result:JSON.parse(e),
            error:true
        }
    }
}
