
import {world} from 'mojang-minecraft';


const commandPrefix = '+';
const commandList = ["lobby","shop","kit_member","help"];
let reply = [];


world.events.beforeChat.subscribe(msg => {
	
	if (msg.message.substr(0, commandPrefix.length) == commandPrefix) {
		
		let args_ = msg.message.slice(commandPrefix.length).trim().split(' '); 
		let command = args_.shift().toLowerCase(); 
		
		let player = msg.sender.name ?? msg.sender.nameTag; 
		msg.cancel = true; 
		


		
		
		 switch (command) {
			case 'shop':
				runCmd(`tellraw "${player}" { "rawtext": [ { "text": "bạn đã tp đến shop" } ] }`,world.getDimension("overworld"));
				 runCmd(`tp "${player}" 20 -60 0`,world.getDimension("overworld"));
				break;
			case 'lobby':
					runCmd(`tp "${player}" 0 -60 0`,world.getDimension("overworld"));
					 runCmd(`tellraw "${player}" { "rawtext": [ { "text": "bạn đã tp đến lobby" } ] }`, world.getDimension("overworld"));
				break;
				 case 'kit_member':
					runCmd(`give "${player}" wooden_sword`,world.getDimension("overworld"));
					 runCmd(`give "${player}" wooden_pickaxe`, world.getDimension("overworld"));
					 runCmd(`give "${player}" apple 16 0`, world.getDimension("overworld"));
				break ;
				 case 'help':
					 runCmd(`tellraw "${player}" { "rawtext": [ { "text": "§l---------------------\n+lobby.    §atp về sảnh\n§f+shop.     §a tp đến khu shop\n §f+kit_member.      nhận kit member" } ] }`, world.getDimension("overworld"));
				break;
				default:
				 runCmd(`tellraw "${player}" { "rawtext": [ { "text": "§a§llệnh méo gì đây nhập §f+help §ađể xem lại đi" } ] }`,world.getDimension("overworld"));
				break;
				
		}
	}
})


function runCmd(cmd, dim) {
	return dim.runCommand(cmd);
}

